from tkinter import *
fenetre = Tk()
fenetre.config(width=1000, height=800, bg='#F0FFF0')
fenetre.title("Convertisseur")
Text = Label(fenetre, text="Convertisseur Binaire, Hexadécimale, Décimale", bg='#F0FFF0', font=('times', 30, 'bold', 'underline'))
Text.place(x=100, y=75)
Texte = Label(fenetre, text="Binaire : 00000000", fg='#FF7F50', font=('times', 20, 'bold'))
Texte1 = Label(fenetre, text="Décimale : 000", fg='#FF7F50', font=('times', 20, 'bold'))
Texte2 = Label(fenetre, text="Hexadécimale : 00", fg='#FF7F50', font=('times', 20, 'bold'))
Texte.place(x=100, y=300)
Texte1.place(x=100, y=330)
Texte2.place(x=100, y=360)
Texte3 = Label(fenetre, text="Décimale : 000", fg='#1E90FF', font=('times', 20, 'bold'))
Texte4 = Label(fenetre, text="Binaire : 00000000", fg='#1E90FF', font=('times', 20, 'bold'))
Texte5 = Label(fenetre, text="Hexadécimale : 00", fg='#1E90FF', font=('times', 20, 'bold'))
Texte3.place(x=100, y=500)
Texte4.place(x=100, y=530)
Texte5.place(x=100, y=560)
def BinVersDec(nb):
    return int(nb, 2)
def DecVersHex(nd):
    return hex(nd)[2:].upper()
def DecVersBin(nd):
    return bin(nd)[2:].zfill(8)
def toggle_bouton(bouton):
    current = bouton.cget('text')
    bouton.config(text='1' if current == '0' else '0', fg='red' if current == '0' else 'black')
def increment_bouton(bouton):
    current = int(bouton.cget('text'))
    new_value = (current + 1) % 10
    bouton.config(text=str(new_value), fg='red' if new_value != 0 else 'black')
def update_from_binary():
    base2 = ''.join([b.cget('text') for b in boutons_bin])
    dec = BinVersDec(base2)
    hexa = DecVersHex(dec)
    Texte.config(text=f"Binaire : {base2}")
    Texte1.config(text=f"Décimale : {dec}")
    Texte2.config(text=f"Hexadécimale : {hexa}")
def update_from_decimal():
    base10 = int(''.join([b.cget('text') for b in boutons_dec]))
    bin_value = DecVersBin(base10)
    hexa = DecVersHex(base10)
    Texte3.config(text=f"Décimale : {base10}")
    Texte4.config(text=f"Binaire : {bin_value}")
    Texte5.config(text=f"Hexadécimale : {hexa}")
boutons_bin = []
for i in range(8):
    bouton = Button(fenetre, text='0', font=('times', 25, 'bold'), command=lambda b=i: (toggle_bouton(boutons_bin[b]), update_from_binary()))
    bouton.place(x=50 + i * 50, y=200)
    boutons_bin.append(bouton)
boutons_dec = []
for i in range(3):
    bouton = Button(fenetre, text='0', font=('times', 25, 'bold'), command=lambda b=i: (increment_bouton(boutons_dec[b]), update_from_decimal()))
    bouton.place(x=50 + i * 50, y=400)
    boutons_dec.append(bouton)
fenetre.mainloop()