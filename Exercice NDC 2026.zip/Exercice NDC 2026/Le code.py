import pyxel
from random import *
mort=[]
Ennemis=[]
bonus=[]
tir=[]
Score=0
def spawn_ennemies():
    global Ennemis
    Ennemis.append(Ennemi(128, randint(1, 104)))
def spawn_bonus():
    global bonus
    bonus.append(Bonus(128, randint(1, 104)))
def clean_up():
    global Ennemis, tir,mort
    for ennemi in Ennemis:
        if ennemi.x > 140 or ennemi.x < -10:
            Ennemis.remove(ennemi)
    for t in tir:
        if t.x > 140 or t.x < -10:
            tir.remove(t)
    for m in mort:
        if m.x > 140 or m.x < -10:
            mort.remove(m)
def contact(x,y,x_ennemi,y_ennemi):
    v=True
    if x+6<x_ennemi:
        v=False
    if x>x_ennemi+15:
        v=False
    if y+6<y_ennemi:
        v=False
    if y>y_ennemi+15:
        v=False
    return v
def destruction(x,y):
    pyxel.blt(x, y, 0, 41, 9, 6, 6, 5, rotate=0, scale=1)

class Joueur:
    def __init__(self, x, y):
        self.x=x
        self.y=y
        self.compte=True
        self.nb_pas=0
        self.balle=20
        self.touche=False
        self.bonus=False
    def update(self):
        global tir
        self.x = max(0, min(self.x, pyxel.width - 8))
        self.y = max(0, min(self.y, pyxel.height - 8))
        if pyxel.btn(pyxel.KEY_UP) or pyxel.btn(pyxel.KEY_Z):
            self.y = self.y - 2
        if pyxel.btn(pyxel.KEY_DOWN) or pyxel.btn(pyxel.KEY_S):
            self.y = self.y + 2
        if pyxel.btn(pyxel.KEY_LEFT) or pyxel.btn(pyxel.KEY_Q):
            self.x = self.x - 2
        if pyxel.btn(pyxel.KEY_RIGHT) or pyxel.btn(pyxel.KEY_D):
            self.x = self.x + 2
        self.nb_pas = (pyxel.frame_count//4)%2
        if self.balle>0:
            if pyxel.frame_count % 5 == 0:
                if pyxel.btn(pyxel.KEY_SPACE) or pyxel.btn(pyxel.KEY_F):
                    self.balle -= 1
                    tir.append(TirAmi(self.x, self.y))
        if self.balle<=0:
            if pyxel.frame_count%240==0:
                self.balle=20
        print(self.balle)
    def draw(self):
        if not self.touche:
            pyxel.blt(self.x,self.y,0,0 + self.nb_pas * 16, 24,16,16,5,rotate=0,scale=1)
        if self.touche:
            if pyxel.frame_count%1==0:
                pyxel.blt(self.x,self.y,0, 48,72,16,16,5,rotate=0,scale=1)
            if pyxel.frame_count%3==0:
                pyxel.blt(self.x,self.y,0,0 + self.nb_pas * 16, 24,16,16,5,rotate=0,scale=1)
        if self.bonus:
            if pyxel.frame_count%1==0:
                pyxel.blt(self.x,self.y,0, 48,72,16,16,5,rotate=0,scale=1)
            if pyxel.frame_count%3==0:
                pyxel.blt(self.x,self.y,0,0 + self.nb_pas * 16, 24,16,16,5,rotate=0,scale=1)
class Ennemi:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.nb_pas=0
    def update(self):
        self.x = self.x - 1
        self.nb_pas = (self.nb_pas + 1) % 4
    def draw(self):
        pyxel.blt(self.x, self.y,0,0 + self.nb_pas * 16, 136,-16, 16,5,rotate=0,scale=1)
class TirAmi:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.nb_tir=0
    def update(self):
        if pyxel.frame_count%1==0:
            self.x=self.x+2
    def draw(self):
        pyxel.blt(self.x, self.y,0,41, 9,6, 6,5,rotate=0,scale=1)
class Mort:
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.nb_vi=0
    def update(self):
        self.x = self.x - 1
        self.nb_vi = (self.nb_vi + 1) % 4
    def draw(self):
        pyxel.blt(self.x, self.y, 0, 192 + self.nb_vi * 16, 32, 6, 6, 5, rotate=0, scale=2)
class Bonus:
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.objet=randint(1,2)
    def update(self):
        self.x = self.x - 1
    def draw(self):
        if self.objet==1:
            pyxel.blt(self.x, self.y, 0,48 , 200, 16, 16,5, rotate=0, scale=1)
        elif self.objet==2:
            pyxel.blt(self.x, self.y, 0,64 , 200, 16, 16,5,  rotate=0, scale=1)
class App:
    def __init__(self):
        pyxel.init(128, 128, title="Mon Jeu de Plateforme")
        pyxel.load("shooter.pyxres")
        self.joueur=Joueur(60,60)
        self.ennemie=Ennemi(30,30)
        self.invinsible = False
        self.mort=False
        self.pause=False
        self.compte=0
        self.compte1 = 0
        self.vie = 10
        self.degat=5
        pyxel.run(self.update, self.draw)
    def update(self):
        global Score
        if pyxel.btnp(pyxel.KEY_P):
            if self.pause:
                self.pause = False
                return
            elif not self.pause:
                self.pause = True
        if self.pause:
            return
        if not self.mort:
            self.joueur.update()
        if not self.mort:
            if pyxel.frame_count % 16 == 0:
                spawn_ennemies()
        if not self.mort:
            if pyxel.frame_count % 300 == 0:
                spawn_bonus()
        if not self.mort:
            if not self.invinsible:
                for e in Ennemis:
                    if contact(self.joueur.x, self.joueur.y, e.x, e.y):
                        mort.append(Mort(e.x,e.y))
                        Ennemis.remove(e)
                        self.vie -= self.degat
                        if self.vie <= 0:
                            self.mort = True
                            self.joueur = None
                            Ennemis.clear()
                        else:
                            self.invinsible = True
                            self.joueur.touche = True
        if self.invinsible:
            self.compte+=1
            if self.compte==150:
                self.invinsible=False
                self.joueur.touche = False
                self.compte=0
        for ennemi in Ennemis:
            ennemi.update()
        for t in tir:
            t.update()
        for m in mort:
            m.update()
        for b in bonus:
            b.update()
        for ennemi in Ennemis:
            for t in tir:
                if contact(t.x, t.y , ennemi.x, ennemi.y):
                    mort.append(Mort(ennemi.x, ennemi.y))
                    Ennemis.remove(ennemi)
                    tir.remove(t)
                    Score+=1
                for b in bonus:
                    if contact(t.x, t.y,b.x,b.y):
                        bonus.remove(b)
        if not self.mort:
            for b in bonus:
                if contact(self.joueur.x,self.joueur.y,b.x,b.y):
                    if b.objet==1:
                        self.vie+=1
                    if b.objet==2:
                        self.degat-=1
                    bonus.remove(b)
                    self.joueur.bonus=True
        if self.joueur.bonus:
            self.compte1+=1
            if self.compte1==90:
                self.joueur.bonus=False
                self.compte1=0
        clean_up()
    def draw(self):
        pyxel.cls(0)
        if not self.mort:
            pyxel.bltm(0, 0,0,pyxel.frame_count%128, 0,128, 128)
        if not self.mort:
            self.joueur.draw()
        if not self.mort:
            for ennemi in Ennemis:
                ennemi.draw()
        if not self.mort:
            for m in mort:
                m.draw()
            for t in tir:
                t.draw()
            for b in bonus:
                b.draw()
        if self.mort:
            pyxel.bltm(0, 0, 0, 128, 0, 128, 128)
            pyxel.text(44, 64, "GAME OVER", 10)
            pyxel.text(20,74,"Votre score est de : "+str(Score),10)
        if not self.mort:
            if self.joueur.balle<=0:
                pyxel.text(44, 100, "Rechargement...", 9)
        if self.pause:
            pyxel.text(self.joueur.x, self.joueur.y-10, "Pause", 9)
        pyxel.text(1, 1, "Score : " + str(Score), 9)
        pyxel.text(100,1,"PV : "+str(self.vie),9)
App()