from tkinter import *
from random import *
fenetre = Tk()
fenetre.config(height=1000, width=1000)
Canevas = Canvas(fenetre, bg='skyblue', height=1000, width=1000)
Canevas.place(x=0, y=0)
NB_LIGNES = 20
NB_COLONNES = 20
TAILLE_PIXEL = 15
Grille_pixel = []
Table_Totoro = [
    [0, 0, 0, 0, 0, 0, 1, 2, 2, 1, 0, 1, 2, 2, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 1, 2, 1, 1, 1, 1, 1, 2, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 1, 2, 1, 3, 4, 3, 4, 4, 1, 2, 1, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 2, 2, 2, 1, 3, 4, 3, 4, 1, 2, 2, 1, 0, 0, 0],
    [0, 0, 0, 0, 1, 2, 2, 2, 2, 1, 3, 3, 1, 2, 2, 2, 1, 0, 0, 0],
    [0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 1, 0, 0],
    [0, 1, 1, 1, 2, 2, 0, 2, 2, 2, 2, 2, 2, 2, 0, 2, 2, 1, 1, 1],
    [0, 0, 1, 1, 2, 0, 1, 0, 2, 2, 2, 2, 2, 0, 1, 0, 2, 1, 1, 0],
    [1, 1, 1, 2, 2, 2, 0, 2, 2, 1, 1, 1, 2, 2, 0, 2, 2, 2, 1, 1],
    [0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1],
    [0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1],
    [1, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2],
    [1, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2],
    [1, 2, 2, 1, 2, 0, 0, 0, 2, 0, 2, 0, 2, 0, 0, 0, 2, 1, 2, 2],
    [1, 2, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 2],
    [1, 1, 2, 2, 0, 0, 0, 2, 0, 2, 0, 2, 0, 2, 0, 0, 0, 2, 2, 1],
    [0, 1, 1, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 1, 1],
    [0, 0, 1, 1, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 1, 1, 0],
    [0, 0, 0, 1, 2, 0, 2, 1, 0, 0, 0, 0, 0, 1, 2, 0, 2, 1, 0, 0],
    [0, 0, 0, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 0, 0]
]

for ligne in range(NB_LIGNES):
    Grille_pixel.append([])

    for colonne in range(NB_COLONNES):
        x0, x1 = colonne * TAILLE_PIXEL, (colonne+1)* TAILLE_PIXEL
        y0, y1= ligne * TAILLE_PIXEL, (ligne +1) * TAILLE_PIXEL
        if Table_Totoro[ligne][colonne] == 0 :
            Grille_pixel[ligne].append(Canevas.create_rectangle(x0, y0, x1, y1, fill = "white"))
        elif Table_Totoro[ligne][colonne] == 1:
            Grille_pixel[ligne].append(Canevas.create_rectangle(x0, y0,x1,y1, fill="black"))
        elif Table_Totoro[ligne][colonne] == 2:
            Grille_pixel[ligne].append(Canevas.create_rectangle(x0, y0, x1, y1, fill="lightgray"))
        elif Table_Totoro[ligne][colonne] == 3:
            Grille_pixel[ligne].append(Canevas.create_rectangle(x0, y0, x1, y1, fill="darkgreen"))
        elif Table_Totoro[ligne][colonne] == 4:
            Grille_pixel[ligne].append(Canevas.create_rectangle(x0, y0, x1, y1, fill="lightgreen"))

def couleur00():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 0:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="black")
def couleur01():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 0:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="lightgray")
def couleur02():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 0:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="darkgreen")
def couleur03():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 0:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="lightgreen")
def couleur04():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 0:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="white")


def couleur10():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 1:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="lightgray")
def couleur11():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 1:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="darkgreen")
def couleur12():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 1:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="lightgreen")
def couleur13():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 1:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="white")
def couleur14():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 1:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="black")


def couleur20():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 2:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="darkgreen")
def couleur21():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 2:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="lightgreen")
def couleur22():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 2:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="white")
def couleur23():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 2:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="black")
def couleur24():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 2:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="lightgray")


def couleur30():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 3:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="lightgreen")
def couleur31():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 3:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="white")
def couleur32():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 3:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="black")
def couleur33():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 3:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="lightgray")
def couleur34():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 3:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="darkgreen")



def couleur40():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 4:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="white")
def couleur41():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 4:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="black")
def couleur42():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 4:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="lightgray")
def couleur43():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 4:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="darkgreen")
def couleur44():
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 4:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="lightgreen")

def DecVersHex1(nd1):
        nh1 = (nd1 // 16, nd1 % 16)
        ListeHex = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F']
        nh_str1 = ListeHex[nh1[0]]+ListeHex[nh1[1]]
        return nh_str1


def DecVersHex2(nd2):
    nh2 = (nd2 // 16, nd2 % 16)
    ListeHex = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']
    nh_str2 = ListeHex[nh2[0]] + ListeHex[nh2[1]]
    return nh_str2

def DecVersHex3(nd3):
    nh3 = (nd3 // 16, nd3 % 16)
    ListeHex = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']
    nh_str3 = ListeHex[nh3[0]] + ListeHex[nh3[1]]
    return nh_str3

def aleatoiree1():
    nd1 = randint(0, 255)
    nd2 = randint(0, 255)
    nd3 = randint(0, 255)
    return DecVersHex1(nd1) + DecVersHex2(nd2) + DecVersHex3(nd3)

def aleatoiree2():
    nd1 = randint(0, 255)
    nd2 = randint(0, 255)
    nd3 = randint(0, 255)
    return DecVersHex1(nd1) + DecVersHex2(nd2) + DecVersHex3(nd3)

def aleatoiree3():
    nd1 = randint(0, 255)
    nd2 = randint(0, 255)
    nd3 = randint(0, 255)
    return DecVersHex1(nd1) + DecVersHex2(nd2) + DecVersHex3(nd3)


def aleatoiree4():
    nd1 = randint(0, 255)
    nd2 = randint(0, 255)
    nd3 = randint(0, 255)
    return DecVersHex1(nd1) + DecVersHex2(nd2) + DecVersHex3(nd3)

def aleatoiree5():
    nd1 = randint(0, 255)
    nd2 = randint(0, 255)
    nd3 = randint(0, 255)
    return DecVersHex1(nd1) + DecVersHex2(nd2) + DecVersHex3(nd3)

def aleatoire():
    couleur = aleatoiree1()
    couleur2 = aleatoiree2()
    couleur3 = aleatoiree3()
    couleur4 = aleatoiree4()
    couleur5 = aleatoiree5()
    for ligne in range(NB_LIGNES):
        for colonne in range(NB_COLONNES):
            if Table_Totoro[ligne][colonne] == 0:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="#" + couleur)
            elif Table_Totoro[ligne][colonne] == 1:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="#" + couleur2)
            elif Table_Totoro[ligne][colonne] == 2:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="#" + couleur3)
            elif Table_Totoro[ligne][colonne] == 3:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="#" + couleur4)
            elif Table_Totoro[ligne][colonne] == 4:
                Canevas.itemconfig(Grille_pixel[ligne][colonne], fill="#" + couleur5)


Bouton0 = Button(fenetre, bg="red", text="noire        ", command=couleur00)
Bouton0.place(x=500, y=300)
Bouton1 = Button(fenetre, bg="red", text="gris         ", command=couleur01)
Bouton1.place(x=600, y=300)
Bouton2 = Button(fenetre, bg="red", text="vert foncé   ", command=couleur02)
Bouton2.place(x=700, y=300)
Bouton3 = Button(fenetre, bg="red", text="vert claire  ", command=couleur03)
Bouton3.place(x=800, y=300)
Bouton4 = Button(fenetre, bg="red", text="blanc        ", command=couleur04)
Bouton4.place(x=900, y=300)

Bouton5 = Button(fenetre, bg="yellow", text="gris         ", command=couleur10)
Bouton5.place(x=500, y=350)
Bouton6 = Button(fenetre, bg="yellow", text="vert foncé   ", command=couleur11)
Bouton6.place(x=600, y=350)
Bouton7 = Button(fenetre, bg="yellow", text="vert clair   ", command=couleur12)
Bouton7.place(x=700, y=350)
Bouton8 = Button(fenetre, bg="yellow", text="blanc        ", command=couleur13)
Bouton8.place(x=800, y=350)
Bouton9 = Button(fenetre, bg="yellow", text="noire        ", command=couleur14)
Bouton9.place(x=900, y=350)

Bouton10 = Button(fenetre, bg="green", text="vert foncé   ", command=couleur20)
Bouton10.place(x=500, y=400)
Bouton11 = Button(fenetre, bg="green", text="vert claire  ", command=couleur21)
Bouton11.place(x=600, y=400)
Bouton12 = Button(fenetre, bg="green", text="blanc        ", command=couleur22)
Bouton12.place(x=700, y=400)
Bouton13 = Button(fenetre, bg="green", text="noire        ", command=couleur23)
Bouton13.place(x=800, y=400)
Bouton14 = Button(fenetre, bg="green", text="gris         ", command=couleur24)
Bouton14.place(x=900, y=400)

Bouton15 = Button(fenetre, bg="pink", text="vert claire  ", command=couleur30)
Bouton15.place(x=500, y=450)
Bouton16 = Button(fenetre, bg="pink", text="blanc        ", command=couleur31)
Bouton16.place(x=600, y=450)
Bouton17 = Button(fenetre, bg="pink", text="noire        ", command=couleur32)
Bouton17.place(x=700, y=450)
Bouton18 = Button(fenetre, bg="pink", text="gris         ", command=couleur33)
Bouton18.place(x=800, y=450)
Bouton19 = Button(fenetre, bg="pink", text="vert foncé   ", command=couleur34)
Bouton19.place(x=900, y=450)

Bouton20 = Button(fenetre, bg="blue", text="blanc        ", command=couleur40)
Bouton20.place(x=500, y=500)
Bouton21 = Button(fenetre, bg="blue", text="noire        ", command=couleur41)
Bouton21.place(x=600, y=500)
Bouton22 = Button(fenetre, bg="blue", text="gris         ", command=couleur42)
Bouton22.place(x=700, y=500)
Bouton23 = Button(fenetre, bg="blue", text="vert foncé   ", command=couleur43)
Bouton23.place(x=800, y=500)
Bouton24 = Button(fenetre, bg="blue", text="vert claire  ", command=couleur44)
Bouton24.place(x=900, y=500)

BoutonA = Button(fenetre,text="aleatoire" ,  bg="lightgray",command=aleatoire)
BoutonA.place(x=300,y=700)

fenetre.mainloop()